FIT Version Control System
==========================

Install:
--------

1. Right-click "install-fit.bat" → Run as Administrator
2. Open a new Command Prompt (or PowerShell)
3. Type:
   fit --help

Uninstall:
----------

Run "uninstall-fit.bat" as Administrator.

Enjoy FIT!
